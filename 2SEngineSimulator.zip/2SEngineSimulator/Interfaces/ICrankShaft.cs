﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _2SEngineSimulator.Interfaces
{
    interface ICrankShaft
    {
        string ModelName { get; set; }
    }
}
